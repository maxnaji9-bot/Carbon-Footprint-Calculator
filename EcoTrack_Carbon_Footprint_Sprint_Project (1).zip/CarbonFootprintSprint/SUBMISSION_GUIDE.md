# What to click and what to submit

You are currently on **KSA DigiChamps Level 12 → Develop the Form Page Logic → Sprint development**.

## 1. See the finished result
1. Extract the ZIP.
2. Open `index.html` in Chrome.
3. Click **Calculate my footprint** to reach `html/form.html`.
4. Confirm that the six tabs work through the Prev/Next buttons.
5. On **Electronic usage**, check **Smartphone**: its hours input appears. Check **Laptop/Desktop**: both rows appear. Uncheck **Smartphone**: only its row disappears. Uncheck all devices: the entire extra question disappears.
6. Move to **Shopping**: the **Next** button disappears and **Submit** appears. Submit shows example results.
7. Click **Home**: you return to `index.html`.

## 2. If using Qubits Live Lab or an online editor
1. Open the workspace your teacher assigned. Find its file explorer.
2. Copy/upload the files from the extracted ZIP, keeping the folder structure shown in README.md.
3. Make sure the script path in `html/form.html` remains `../javascript/formPage.js`.
4. Run/preview `index.html` or open the app's preview option and verify the interactions.

**Note:** This guide does not assume what the Qubits submission interface looks like. Your teacher may want a GitHub repository link, a project ZIP, or the Live Lab project. Check the specific instruction on the assignment's final page.

## 3. If your teacher wants GitHub commits
1. Open your existing project repository on GitHub (or create a new one if required).
2. Upload `index.html` and the `html/`, `javascript/`, and `css/` folders (and optionally the README) in their existing structure.
3. Enter a commit message such as `Implement form page visibility and tab navigation` and commit.
4. Invite collaborators only if required and if you know their GitHub usernames.
5. Copy the repository link for your submission if your assignment requests it.

**Important:** I cannot claim that a GitHub repository, Qubits submission, or Live Lab project has been created in your account. The ZIP is the code package to upload yourself.

## 4. Take screenshots if required
Useful evidence of completed logic includes: Electronic usage with Smartphone selected, Electronic usage with multiple devices selected, Shopping with Submit visible, and the results display.
