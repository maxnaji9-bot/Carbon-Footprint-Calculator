# EcoTrack — Carbon Footprint Calculator

**KSA DigiChamps Level 12 — Develop the Form Page Logic — Sprint Development, Task 3**

This student-friendly sample website implements the exact core interactions described on the provided course page. It also includes a homepage, original styling, and an *illustrative* results screen.

## Open the project

1. Download the ZIP and **Extract All** (Windows) / double-click the ZIP (Mac).
2. Open the extracted `CarbonFootprintSprint` folder.
3. Double-click `index.html` to open the homepage in Chrome.
4. Click **Calculate my footprint**.
5. Try **Next** and **Prev** between the 6 tabs. On **Electronic usage**, check and uncheck devices to see their number inputs appear or disappear. On the **Shopping** tab, **Submit** appears instead of **Next**. Click **Home** to return to the landing page.

## Required folder structure

```
CarbonFootprintSprint/
  index.html
  html/
    form.html
  javascript/
    formPage.js
  css/
    style.css
  README.md
  SUBMISSION_GUIDE.md
```

## How this matches the lesson

| Lesson requirement | Included implementation |
| --- | --- |
| Link JavaScript file before `</body>` | `html/form.html` includes `<script src="../javascript/formPage.js"></script>` |
| Checkbox ids | `smartphone`, `laptop`, `gamingConsole`, `television` |
| Show/hide second question | `questionLabel` with `d-none` / `d-block` |
| Show/hide matching number input row | `phoneUsageBlock`, `laptopUsageBlock`, `consoleUsageBlock`, `tvUsageBlock` with `d-none` / `d-flex` |
| `querySelectorAll`, `forEach`, change listeners | In `javascript/formPage.js` |
| Tabs | `General`, `Home`, `Travel`, `Food`, `Electronic usage`, `Shopping` |
| Only button-driven navigation | Tab links are disabled for direct clicks; `Next` / `Prev` unlock the appropriate tab and call `.click()` |
| Sibling navigation | `parentElement.nextElementSibling`, `parentElement.previousElementSibling` |
| Final tab shows Submit instead of Next | `nextButton` / `submitButton` visibility updates automatically |
| Calculate from homepage to form page | `index.html` links to `html/form.html` |
| Home button returns to homepage | `window.location.href = "../index.html"` |
| Save code to Git | Follow SUBMISSION_GUIDE.md and commit files in your project repository |

## Educational emissions estimate

The Results screen is an **optional extra** beyond the supplied Task 3. It uses example, non-regionalized factors:

- Home: 0.55 kg CO2e per kWh, divided among household members, adjusted by the selected renewable share.
- Travel: car 0.171 / bus 0.103 / train 0.041 kg CO2e per passenger-km; flight 0.18 per km.
- Food: illustrative dietary averages from 2.5 to 7 kg CO2e daily.
- Shopping: an illustrative 8 kg CO2e per item with a discount for second-hand purchasing frequency.

These are **not** authoritative measurements and should not be used for real carbon accounting. Electronic hours are collected but intentionally not added to the score: electricity for those devices is generally covered by the household electricity input.

## Before turning it in

Your provided lesson shows **Task 3**. Earlier lesson tasks may require additional layouts or a starter project not visible in the pasted text. If your teacher gave you starter files, compare their HTML structure and file locations before replacing them.
