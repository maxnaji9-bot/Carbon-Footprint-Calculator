// EcoTrack - Sprint development: form-page JavaScript logic
// Course requirements: dynamic components, Next/Prev tab navigation,
// Submit on final tab, and Home navigation.

'use strict';

const checkBoxes = document.querySelectorAll('.form-check-input');
const nextButton = document.getElementById('nextButton');
const prevButton = document.getElementById('prevButton');
const submitButton = document.getElementById('submitButton');
const homeButton = document.getElementById('homeButton');
const allTabs = document.querySelectorAll('.nav-link');
const formMessage = document.getElementById('formMessage');

// TASK 3: Dynamic component visibility.
// Each checkbox displays only its own row of number inputs.
checkBoxes.forEach((eachCheckBox) => {
  eachCheckBox.addEventListener('change', showComponents);
});

function showComponents(event) {
  const target = event.target;
  const targetId = target.id;

  const usageBlocks = {
    smartphone: 'phoneUsageBlock',
    laptop: 'laptopUsageBlock',
    gamingConsole: 'consoleUsageBlock',
    television: 'tvUsageBlock'
  };

  if (Object.prototype.hasOwnProperty.call(usageBlocks, targetId)) {
    const block = document.getElementById(usageBlocks[targetId]);
    if (target.checked) {
      block.classList.add('d-flex');
      block.classList.remove('d-none');
    } else {
      block.classList.add('d-none');
      block.classList.remove('d-flex');
    }
  }

  // The second question stays visible while at least one device is checked.
  let isChecked = false;
  checkBoxes.forEach((eachCheckBox) => {
    if (eachCheckBox.checked) isChecked = true;
  });
  const questionLabel = document.getElementById('questionLabel');
  if (isChecked) {
    questionLabel.classList.add('d-block');
    questionLabel.classList.remove('d-none');
  } else {
    questionLabel.classList.add('d-none');
    questionLabel.classList.remove('d-block');
  }
}

// Accessible, dependency-free tab handling. Tab links cannot be used directly;
// only Prev and Next temporarily unlock a link to activate its panel.
function activateTab(tabLink) {
  if (tabLink.classList.contains('disabled')) return;

  allTabs.forEach((tab) => {
    tab.classList.remove('active');
    tab.removeAttribute('aria-current');
    tab.classList.add('disabled');
    tab.setAttribute('tabindex', '-1');
  });
  document.querySelectorAll('.tab-pane').forEach((pane) => {
    pane.classList.remove('active');
    pane.hidden = true;
  });

  tabLink.classList.add('active');
  tabLink.setAttribute('aria-current', 'step');
  const targetPane = document.querySelector(tabLink.getAttribute('data-bs-target'));
  targetPane.classList.add('active');
  targetPane.hidden = false;
  tabLink.classList.add('disabled');

  const activeIndex = Array.from(allTabs).indexOf(tabLink);
  const last = activeIndex === allTabs.length - 1;
  const first = activeIndex === 0;
  prevButton.classList.toggle('d-none', first);
  nextButton.classList.toggle('d-none', last);
  nextButton.classList.toggle('d-inline', !last);
  submitButton.classList.toggle('d-none', !last);
  submitButton.classList.toggle('d-inline', last);
  document.getElementById('stepIndicator').textContent = `STEP ${activeIndex + 1} OF ${allTabs.length}`;
  const progress = Math.round((activeIndex + 1) / allTabs.length * 100);
  document.getElementById('progressFill').style.width = `${progress}%`;
  document.getElementById('progressBar').setAttribute('aria-valuenow', String(progress));
  formMessage.hidden = true;
  document.getElementById('results').hidden = true;
}

allTabs.forEach((tab) => {
  tab.addEventListener('click', (event) => {
    event.preventDefault();
    activateTab(tab);
  });
});

// TASK 3: Navigate through the tabs using sibling elements.
nextButton.addEventListener('click', showNextTab);
prevButton.addEventListener('click', showPreviousTab);

function showNextTab() {
  const activeTabLink = document.querySelector('.nav-link.active');
  const nextTabListItem = activeTabLink.parentElement.nextElementSibling;
  if (nextTabListItem) {
    allTabs.forEach((tab) => tab.classList.add('disabled'));
    const nextTab = nextTabListItem.querySelector('.nav-link');
    nextTab.classList.remove('disabled');
    nextTab.click();
  }
}

function showPreviousTab() {
  const activeTabLink = document.querySelector('.nav-link.active');
  const prevTabListItem = activeTabLink.parentElement.previousElementSibling;
  if (prevTabListItem) {
    allTabs.forEach((tab) => tab.classList.add('disabled'));
    const prevTab = prevTabListItem.querySelector('.nav-link');
    prevTab.classList.remove('disabled');
    prevTab.click();
  }
}

// TASK 3: Home button opens the project's index.html.
homeButton.addEventListener('click', showHome);
function showHome() {
  window.location.href = '../index.html';
}

// Optional enhancement: show a simple illustrative footprint on Submit.
// This is educational sample math, not a scientifically validated footprint.
function getNumber(id) {
  const el = document.getElementById(id);
  const value = Number(el.value);
  if (!Number.isFinite(value) || value < 0 || (el.max !== '' && value > Number(el.max))) {
    throw new Error(`Please enter a valid number for ${el.closest('.field, .row')?.querySelector('label')?.textContent || id}.`);
  }
  return value;
}

submitButton.addEventListener('click', function () {
  formMessage.hidden = true;
  try {
    const household = getNumber('householdSize');
    if (!Number.isInteger(household) || household < 1) throw new Error('Enter a valid number of household members (at least 1).');
    const renewable = Number(document.getElementById('renewable').value);
    // The user's share of household electricity, estimated at 0.55 kg CO2e/kWh.
    const home = getNumber('electricity') * 0.55 * (1 - renewable) / household;
    // Monthly travel from weekly values (52 weeks / 12 months).
    const travel = (getNumber('carKm') * 0.171 + getNumber('busKm') * 0.103 + getNumber('trainKm') * 0.041) * (52 / 12) + getNumber('flightKm') * 0.18;
    const diet = document.querySelector('input[name="diet"]:checked').value;
    const dailyDietFactors = { vegan: 2.5, vegetarian: 3.5, mixed: 5.0, 'meat-heavy': 7.0 };
    const food = dailyDietFactors[diet] * 30;
    const secondHand = document.getElementById('buySecondhand').value;
    const shoppingDiscount = { never: 1, sometimes: 0.85, often: 0.7 }[secondHand];
    const shopping = getNumber('purchases') * 8 * shoppingDiscount;
    // Electronic device use is not added to total because household electricity
    // likely includes it. The dynamic device fields are still fully functional.
    checkBoxes.forEach((checkbox) => {
      if (checkbox.checked) {
        const related = {
          smartphone: 'phoneUsage', laptop: 'laptopUsage',
          gamingConsole: 'consoleUsage', television: 'tvUsage'
        }[checkbox.id];
        getNumber(related);
      }
    });
    const total = home + travel + food + shopping;
    document.getElementById('totalEmissions').textContent = total.toFixed(1);
    const name = document.getElementById('fullName').value.trim();
    document.getElementById('resultGreeting').textContent = `${name ? name + ', your' : 'Your'} illustrative monthly total is shown below. This estimate covers home electricity, transport, food and shopping.`;

    const breakdown = document.getElementById('resultsBreakdown');
    breakdown.replaceChildren();
    [
      ['🏠 Home electricity', home],
      ['🚗 Travel', travel],
      ['🥗 Food', food],
      ['🛍️ Shopping', shopping]
    ].forEach(([label, amount]) => {
      const item = document.createElement('div');
      const heading = document.createElement('div');
      heading.className = 'breakdown-head';
      const text = document.createElement('span'); text.textContent = label;
      const value = document.createElement('span'); value.textContent = `${amount.toFixed(1)} kg`;
      heading.append(text, value);
      const track = document.createElement('div'); track.className = 'breakdown-track';
      const fill = document.createElement('div'); fill.className = 'breakdown-fill';
      fill.style.width = `${total ? amount / total * 100 : 0}%`;
      track.appendChild(fill); item.append(heading, track); breakdown.append(item);
    });
    const results = document.getElementById('results');
    results.hidden = false;
    results.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    formMessage.textContent = error.message;
    formMessage.hidden = false;
  }
});

document.getElementById('editAnswersButton').addEventListener('click', function () {
  document.getElementById('results').hidden = true;
  document.getElementById('footprintForm').scrollIntoView({ behavior: 'smooth', block: 'start' });
});
